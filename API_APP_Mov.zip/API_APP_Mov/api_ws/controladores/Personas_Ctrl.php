<?php

class Personas_Ctrl
{
   public $M_Personas=null;
   public function __construct(){
    $this->M_Personas= new M_Personas();
   }
   public function ppp($f3)
    {

        echo "hola";
    }
   public function listar($f3){
    $resultado=$this->M_Personas->find(["estado='E'"]);
    $items[]=array();
    foreach($resultado as $persona ){
        $items[]=$persona->cast();
    }

    echo json_encode(
        [
            'cantidad'=>count($items),
            'mensaje'=>count($items)>0? 'Consulta con Datos':'Consulta sin Datos',
            'data'=>$items
        ]
    ); 
 
}
public function listarSQL($f3){
    $cadenaSQL="";
    $cadenaSQL=$cadenaSQL . " select * ";
    $cadenaSQL=$cadenaSQL . " from persona ";
    $cadenaSQL=$cadenaSQL . " where estado='A' ";

    $resultado=$f3->DB->exec($cadenaSQL);
    //codificar a objetos JSON

    echo json_encode([
        'cantidad'=>count($resultado),
        'data'=>$resultado
    ]
    );
}
public function fun_personaporcedula($f3){
    $ced=$f3->get('POST.micedula');
    $existe=0;
    $mensaje="";

    $persona=new M_Personas();
    $persona->load(['cedula=?',$ced]);
    $resultado=array();
    if($persona->loaded()>0){
        $mensaje="Persona encontrada";
        $resultado=$persona->cast();
        $existe=1;
    }else{
        $mensaje="No existe la persona buscada";
        $existe=0;
    }
    echo json_encode([
        'mensaje'=>$mensaje,
        'existe'=>$existe,
        'data'=>$resultado
    ]
    );
}

public function fun_personaxcedSQL($f3){
    $ced=$f3->get('POST.micedula');
    $cadenaSQL="";
    $cadenaSQL=$cadenaSQL . " select * from persona where cedula='".$ced."'";
    $resultado=$f3->DB->exec($cadenaSQL);

    echo json_encode([
        'cantidad'=>count($resultado),
        'data'=>$resultado
    ]);
    
}

public function fun_personaInsertar($f3){
    $persona=new M_Personas();
    $mensaje="";
    $id=0;
    $persona->load(['cedula=?',$f3->get('POST.pcedula')]);
    if($persona->loaded()>0){
        $mensaje=" Ya existe uan persona con la cedula que intenata registrar :v";
    }else{
        $this->M_Personas->set('cedula',$f3->get('POST.pcedula'));
        $this->M_Personas->set('nombres',$f3->get('POST.pnombres'));
        $this->M_Personas->set('apellidos',$f3->get('POST.papellidos'));
        $this->M_Personas->set('estado','A');
        $this->M_Personas->save();
        $id=$this->M_Personas->get('id');
        $mensaje="Persona registrada correctamente xd ";
    }
    echo json_encode([
        'id'=>$id,
        'mensaje'=>$mensaje
    ]);
    

}

public function fun_personaInsertarSQL($f3){
    $cedula=$f3->get('POST.pcedula');
    $nombres=$f3->get('POST.pnombres');
    $apellidos=$f3->get('POST.papellidos');
    $estado='A';

    $cadenaSQL="";
    $cadenaSQL=$cadenaSQL. " insert into persona ";
    $cadenaSQL=$cadenaSQL. " (cedula,nombres,apellidos,estado) ";
    $cadenaSQL=$cadenaSQL. " values ( ";
    $cadenaSQL=$cadenaSQL. "'".$cedula."',";
    $cadenaSQL=$cadenaSQL. "'".$nombres."',";
    $cadenaSQL=$cadenaSQL. "'".$apellidos."',";
    $cadenaSQL=$cadenaSQL. "'".$estado."')";
    //echo $cadenaSQL;
    $resultado=$f3->DB->exec($cadenaSQL);
    echo json_encode(
        [
            'mensaje'=>"se inserto correctamente"
        ]
        );
}
public function fun_Modificar($f3){
    /* $cedula=$f3->get('POST.pcedula');
    $nombres=$f3->get('POST.pnombres');
    $apellidos=$f3->get('POST.papellidos');
    $estado=$f3->get('POST.pestado');
    echo "el nombres es:" .$nombres; */
    $id=0;
    $mensaje="";
    $this->M_Personas->load(['cedula=?',$f3->get('POST.pcedula')]);
    if($this->M_Personas->loaded()>0){
        $this->M_Personas->set('cedula',$f3->get('POST.pcedula'));
        $this->M_Personas->set('nombres',$f3->get('POST.pnombres'));
        $this->M_Personas->set('apellidos',$f3->get('POST.papellidos'));
        $this->M_Personas->set('estado','A');
        $this->M_Personas->save();
       // $id=$this->M_Personas->get('id');
        $id=1;
        $mensaje="Persona registrada correctamente xd ";
    }else{
        $mensaje="No se puedo registrar ";
    }
        echo json_encode([
            'id'=>$id,
            'mensaje'=>$mensaje
        ]);
    }

    public function fun_ModificarSQL($f3){
    $cedula=$f3->get('POST.pcedula');
    $nombres=$f3->get('POST.pnombres');
    $apellidos=$f3->get('POST.papellidos');
    $estado=$f3->get('POST.pestado');
        $cadenaSQL="";
        $cadenaSQL=$cadenaSQL. " update persona ";
        $cadenaSQL=$cadenaSQL. " set nombres='".$nombres."',";
        $cadenaSQL=$cadenaSQL. " apellidos='".$apellidos."',";
        $cadenaSQL=$cadenaSQL. " estado='".$estado."'";
        $cadenaSQL=$cadenaSQL. " where cedula='".$cedula."'";
        //echo $cadenaSQL;
        $resultado=$f3->DB->exec($cadenaSQL);
        
        echo json_encode(
        [
            'mensaje'=>"se modifico correctamente"
        ]
        );
    }

    public function fun_eliminarSQL($f3){
        $cedula=$f3->get('POST.pcedula');
        $cadenaSQL="";
        $cadenaSQL=$cadenaSQL . " delete from persona where cedula='".$cedula."'";
        echo $cadenaSQL;

        /* $resultado=$f3->DB->exec($cadenaSQL);

        echo json_encode(
        [
            'mensaje'=>"se elimino correctamente"
        ]
        ); */


    }
}

    