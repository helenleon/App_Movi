<?php
class Clientes_Ctrl
{
    public $M_Clientes=null;
   public function __construct(){
    $this->M_Clientes= new M_Clientes();
   }


    public function listarClientes($f3){
        $resultado=$this->M_Clientes->find([""]);
        $items[]=array();
        foreach($resultado as $clientes ){
            $items[]=$clientes->cast();
        }
    
        echo json_encode(
            [
                'cantidad'=>count($items),
                'mensaje'=>count($items)>0? 'Consulta con Datos':'Consulta sin Datos',
                'data'=>$items
            ]
        ); 

    }

    public function fun_clientesxc($f3){
        $identificacion=$f3->get('POST.mi_identificacion');
        $existe=0;
        $mensaje="";
    
        $clientes=new M_Clientes();
        $clientes->load(['identificacion=?',$identificacion]);
        $resultado=array();
        if($clientes->loaded()>0){
            $mensaje="Cliente encontrado";
            $resultado=$clientes->cast();
            $existe=1;
        }else{
            $mensaje="No existe el cliente buscado";
            $existe=0;
        }
        echo json_encode([
            'mensaje'=>$mensaje,
            'existe'=>$existe,
            'data'=>$resultado
        ]
        );
    }

       
public function fun_InsertarCliente($f3){
    $clientes=new M_Clientes();
    $mensaje="";
    $id=0;
    $clientes->load(['identificacion=?',$f3->get('POST.pidentificacion')]);
    if($clientes->loaded()>0){
        $mensaje=" Ya existe un cliente con la identificacion que intenta registrar :v";
    }else{
        $this->M_Clientes->set('identificacion',$f3->get('POST.pidentificacion'));
        $this->M_Clientes->set('nombre',$f3->get('POST.pnombre'));
        $this->M_Clientes->set('telefono',$f3->get('POST.ptelefono'));
        $this->M_Clientes->set('correo',$f3->get('POST.pcorreo'));
        $this->M_Clientes->set('direccion',$f3->get('POST.pdireccion'));
        $this->M_Clientes->set('pais',$f3->get('POST.ppais'));
        $this->M_Clientes->set('ciudad',$f3->get('POST.pciudad'));
        $this->M_Clientes->save();
        $id=$this->M_Clientes->get('id');
        $mensaje="Cliente registrado correctamente xd ";
    }
    echo json_encode([
        'id'=>$id,
        'mensaje'=>$mensaje
    ]);
    
}


public function fun_ModificarCliente($f3){
    $id=0;
    $mensaje="";
    $this->M_Clientes->load(['identificacion=?',$f3->get('POST.pidentificacion')]);
    if($this->M_Clientes->loaded()>0){
        $this->M_Clientes->set('identificacion',$f3->get('POST.pidentificacion'));
        $this->M_Clientes->set('nombre',$f3->get('POST.pnombre'));
        $this->M_Clientes->set('telefono',$f3->get('POST.ptelefono'));
        $this->M_Clientes->set('correo',$f3->get('POST.pcorreo'));
        $this->M_Clientes->set('direccion',$f3->get('POST.pdireccion'));
        $this->M_Clientes->set('pais',$f3->get('POST.ppais'));
        $this->M_Clientes->set('ciudad',$f3->get('POST.pciudad'));
        $this->M_Clientes->save();
    
        $id=1;
        $mensaje="Cliente modificado correctamente xd ";
    }else{
        $mensaje="No se pudo modificar ";
    }
        echo json_encode([
            'id'=>$id,
            'mensaje'=>$mensaje
        ]);
    }



    




}    