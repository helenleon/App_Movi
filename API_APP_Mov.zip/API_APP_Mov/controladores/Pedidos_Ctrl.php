<?php
class Pedidos_Ctrl
{
    public $M_Pedidos=null;
   public function __construct(){
    $this->M_Pedidos= new M_Pedidos();
   }


    public function listarPedidos($f3){
        $resultado=$this->M_Pedidos->find([""]);
        $items[]=array();
        foreach($resultado as $pedidos ){
            $items[]=$pedidos->cast();
        }
    
        echo json_encode(
            [
                'cantidad'=>count($items),
                'mensaje'=>count($items)>0? 'Consulta con Datos':'Consulta sin Datos',
                'data'=>$items
            ]
        ); 

    }

    public function fun_Pedidosxc($f3){
        $cliente_id=$f3->get('POST.mi_cliente_id');
        $existe=0;
        $mensaje="";
    
        $pedidos=new M_Pedidos();
        $pedidos->load(['cliente_id=?',$cliente_id]);
        $resultado=array();
        if($pedidos->loaded()>0){
            $mensaje="Pedido encontrado";
            $resultado=$pedidos->cast();
            $existe=1;
        }else{
            $mensaje="No existe el Pedido buscado";
            $existe=0;
        }
        echo json_encode([
            'mensaje'=>$mensaje,
            'existe'=>$existe,
            'data'=>$resultado
        ]
        );
    }

       
public function fun_InsertarPedido($f3){
    $pedidos=new M_Pedidos();
    $mensaje="";
    $id=0;
    $pedidos->load(['cliente_id=?',$f3->get('POST.pcliente_id')]);
    if($pedidos->loaded()>0){
        $mensaje=" Ya existe un pedido con el Cliente ID que intenta registrar :v";
    }else{
        $this->M_Pedidos->set('cliente_id',$f3->get('POST.pcliente_id'));
        $this->M_Pedidos->set('fecha',$f3->get('POST.pfecha'));
        $this->M_Pedidos->set('usuario_id',$f3->get('POST.pusuario_id'));
        $this->M_Pedidos->set('estado',$f3->get('POST.pestado'));
        $this->M_Pedidos->save();
        $id=$this->M_Pedidos->get('id');
        $mensaje="Pedido registrado correctamente xd ";
    }
    echo json_encode([
        'id'=>$id,
        'mensaje'=>$mensaje
    ]);
    
}


public function fun_ModificarPedido($f3){
    $id=0;
    $mensaje="";
    $this->M_Pedidos->load(['cliente_id=?',$f3->get('POST.pcliente_id')]);
    if($this->M_Pedidos->loaded()>0){
        $this->M_Pedidos->set('cliente_id',$f3->get('POST.pcliente_id'));
        $this->M_Pedidos->set('fecha',$f3->get('POST.pfecha'));
        $this->M_Pedidos->set('usuario_id',$f3->get('POST.pusuario_id'));
        $this->M_Pedidos->set('estado',$f3->get('POST.pestado'));
        
        $this->M_Pedidos->save();
 
        $id=1;
        $mensaje="Pedido modificado correctamente xd ";
    }else{
        $mensaje="No se pudo modificar ";
    }
        echo json_encode([
            'id'=>$id,
            'mensaje'=>$mensaje
        ]);
    }


 
    




}    