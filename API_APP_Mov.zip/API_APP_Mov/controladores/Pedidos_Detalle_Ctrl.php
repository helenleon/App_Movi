<?php
class Pedidos_Detalle_Ctrl
{
    public $M_Pedidos_Detalle=null;
   public function __construct(){
    $this->M_Pedidos_Detalle= new M_Pedidos_Detalle();
   }


    public function listarPedididoDetalle($f3){
        $resultado=$this->M_Pedidos_Detalle->find([""]);
        $items[]=array();
        foreach($resultado as $pedidos_detalle ){
            $items[]=$pedidos_detalle->cast();
        }
    
        echo json_encode(
            [
                'cantidad'=>count($items),
                'mensaje'=>count($items)>0? 'Consulta con Datos':'Consulta sin Datos',
                'data'=>$items
            ]
        ); 

    }

    public function fun_PedidosxProd($f3){
        $producto_id=$f3->get('POST.mi_producto_id');
        $existe=0;
        $mensaje="";
    
        $pedidos_detalle=new M_Pedidos_Detalle();
        $pedidos_detalle->load(['producto_id=?',$producto_id]);
        $resultado=array();
        if($pedidos_detalle->loaded()>0){
            $mensaje="Pedido del detalle encontrado";
            $resultado=$pedidos_detalle->cast();
            $existe=1;
        }else{
            $mensaje="No existe el Pedido de detalle buscado";
            $existe=0;
        }
        echo json_encode([
            'mensaje'=>$mensaje,
            'existe'=>$existe,
            'data'=>$resultado
        ]
        );
    }


public function fun_InsertarPedidoDetalle($f3){
    $pedidos_detalle=new M_Pedidos_Detalle();
    $mensaje="";
    $id=0;
    $pedidos_detalle->load(['producto_id=?',$f3->get('POST.pproducto_id')]);
    if($pedidos_detalle->loaded()>0){
        $mensaje=" Ya existe un pedido Detalle con el Producto ID que intenta registrar :v";
    }else{
        $this->M_Pedidos_Detalle->set('producto_id',$f3->get('POST.pproducto_id'));
        $this->M_Pedidos_Detalle->set('pedido_id',$f3->get('POST.ppedido_id'));
        $this->M_Pedidos_Detalle->set('cantidad',$f3->get('POST.pcantidad'));
        $this->M_Pedidos_Detalle->set('precio',$f3->get('POST.pprecio'));
        $this->M_Pedidos_Detalle->save();
        $id=$this->M_Pedidos_Detalle->get('id');
        $mensaje="Pedido Detalle registrado correctamente xd ";
    }
    echo json_encode([
        'id'=>$id,
        'mensaje'=>$mensaje
    ]);
    
}


public function fun_ModificarPedidoDetalle($f3){
    $id=0;
    $mensaje="";
    $this->M_Pedidos_Detalle->load(['producto_id=?',$f3->get('POST.pproducto_id')]);
    if($this->M_Pedidos_Detalle->loaded()>0){
        $this->M_Pedidos_Detalle->set('producto_id',$f3->get('POST.pproducto_id'));
        $this->M_Pedidos_Detalle->set('pedido_id',$f3->get('POST.ppedido_id'));
        $this->M_Pedidos_Detalle->set('cantidad',$f3->get('POST.pcantidad'));
        $this->M_Pedidos_Detalle->set('precio',$f3->get('POST.pprecio'));
        
        $this->M_Pedidos_Detalle->save();
       // $id=$this->M_Personas->get('id');
        $id=1;
        $mensaje="Pedido Detalle modificado correctamente xd ";
    }else{
        $mensaje="No se pudo modificar ";
    }
        echo json_encode([
            'id'=>$id,
            'mensaje'=>$mensaje
        ]);
    }


  
    




}    