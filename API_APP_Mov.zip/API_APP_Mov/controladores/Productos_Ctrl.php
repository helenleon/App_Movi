<?php
class Productos_Ctrl
{
    public $M_Productos=null;
   public function __construct(){
    $this->M_Productos= new M_Productos();
   }


    public function listarProductos($f3){
        $resultado=$this->M_Productos->find([""]);
        $items[]=array();
        foreach($resultado as $productos ){
            $items[]=$productos->cast();
        }
    
        echo json_encode(
            [
                'cantidad'=>count($items),
                'mensaje'=>count($items)>0? 'Consulta con Datos':'Consulta sin Datos',
                'data'=>$items
            ]
        ); 

    }

    public function fun_ProductosxCod($f3){
        $codigo=$f3->get('POST.mi_codigo');
        $existe=0;
        $mensaje="";
    
        $productos=new M_Productos();
        $productos->load(['codigo=?',$codigo]);
        $resultado=array();
        if($productos->loaded()>0){
            $mensaje="Producto encontrado";
            $resultado=$productos->cast();
            $existe=1;
        }else{
            $mensaje="No existe el Producto buscado";
            $existe=0;
        }
        echo json_encode([
            'mensaje'=>$mensaje,
            'existe'=>$existe,
            'data'=>$resultado
        ]
        );
    }

       
public function fun_InsertarProducto($f3){
    $productos=new M_Productos();
    $mensaje="";
    $id=0;
    $productos->load(['codigo=?',$f3->get('POST.pcodigo')]);
    if($productos->loaded()>0){
        $mensaje=" Ya existe un producto con el codigo que intenta registrar :v";
    }else{
        $this->M_Productos->set('codigo',$f3->get('POST.pcodigo'));
        $this->M_Productos->set('nombre',$f3->get('POST.pnombre'));
        $this->M_Productos->set('stock',$f3->get('POST.pstock'));
        $this->M_Productos->set('precio',$f3->get('POST.pprecio'));
        $this->M_Productos->set('activo',$f3->get('POST.pactivo'));
        $this->M_Productos->set('imagen',$f3->get('POST.pimagen'));

        $this->M_Productos->save();
        $id=$this->M_Productos->get('id');
        $mensaje="Producto registrado correctamente xd ";
    }
    echo json_encode([
        'id'=>$id,
        'mensaje'=>$mensaje
    ]);
    
}


public function fun_ModificarProducto($f3){
    $id=0;
    $mensaje="";
    $this->M_Productos->load(['codigo=?',$f3->get('POST.pcodigo')]);
    if($this->M_Productos->loaded()>0){
        $this->M_Productos->set('codigo',$f3->get('POST.pcodigo'));
        $this->M_Productos->set('nombre',$f3->get('POST.pnombre'));
        $this->M_Productos->set('stock',$f3->get('POST.pstock'));
        $this->M_Productos->set('precio',$f3->get('POST.pprecio'));
        $this->M_Productos->set('activo',$f3->get('POST.pactivo'));
        $this->M_Productos->set('imagen',$f3->get('POST.pimagen'));
        
        $this->M_Productos->save();
       // $id=$this->M_Personas->get('id');
        $id=1;
        $mensaje="Producto modificado correctamente xd ";
    }else{
        $mensaje="No se pudo modificar ";
    }
        echo json_encode([
            'id'=>$id,
            'mensaje'=>$mensaje
        ]);
    }


 
    

 


}    