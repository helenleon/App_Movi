<?php
class Usuarios_Ctrl
{
    public $M_Usuarios=null;
   public function __construct(){
    $this->M_Usuarios= new M_Usuarios();
   }


    public function listar($f3){
        $resultado=$this->M_Usuarios->find([""]);
        $items[]=array();
        foreach($resultado as $usuarios ){
            $items[]=$usuarios->cast();
        }
    
        echo json_encode(
            [
                'cantidad'=>count($items),
                'mensaje'=>count($items)>0? 'Consulta con Datos':'Consulta sin Datos',
                'data'=>$items
            ]
        ); 

    }

    public function fun_usuariosxc($f3){
        $clave=$f3->get('POST.miclave');
        $existe=0;
        $mensaje="";
    
        $usuarios=new M_Usuarios();
        $usuarios->load(['clave=?',$clave]);
        $resultado=array();
        if($usuarios->loaded()>0){
            $mensaje="Usuario encontrado";
            $resultado=$usuarios->cast();
            $existe=1;
        }else{
            $mensaje="No existe el Usuario buscado";
            $existe=0;
        }
        echo json_encode([
            'mensaje'=>$mensaje,
            'existe'=>$existe,
            'data'=>$resultado
        ]
        );
    }
    
    
public function fun_Insertar($f3){
    $usuarios=new M_Usuarios();
    $mensaje="";
    $id=0;
    $usuarios->load(['clave=?',$f3->get('POST.pclave')]);
    if($usuarios->loaded()>0){
        $mensaje=" Ya existe un usuario con la clave que intenata registrar :v";
    }else{
        $this->M_Usuarios->set('usuario',$f3->get('POST.pusuario'));
        $this->M_Usuarios->set('clave',$f3->get('POST.pclave'));
        $this->M_Usuarios->set('nombre',$f3->get('POST.pnombre'));
        $this->M_Usuarios->set('telefono',$f3->get('POST.ptelefono'));
        $this->M_Usuarios->set('correo',$f3->get('POST.pcorreo'));
        $this->M_Usuarios->set('activo',$f3->get('POST.pactivo'));
        $this->M_Usuarios->save();
        $id=$this->M_Usuarios->get('id');
        $mensaje="Usuario registrado correctamente xd ";
    }
    echo json_encode([
        'id'=>$id,
        'mensaje'=>$mensaje
    ]);
    
}

public function fun_Modificar($f3){
    $id=0;
    $mensaje="";
    $this->M_Usuarios->load(['clave=?',$f3->get('POST.pclave')]);
    if($this->M_Usuarios->loaded()>0){
        $this->M_Usuarios->set('usuario',$f3->get('POST.pusuario'));
        $this->M_Usuarios->set('clave',$f3->get('POST.pclave'));
        $this->M_Usuarios->set('nombre',$f3->get('POST.pnombre'));
        $this->M_Usuarios->set('telefono',$f3->get('POST.ptelefono'));
        $this->M_Usuarios->set('correo',$f3->get('POST.pcorreo'));
        $this->M_Usuarios->set('activo',$f3->get('POST.pactivo'));
        $this->M_Usuarios->save();
       
        $id=1;
        $mensaje="Usuario modificado correctamente xd ";
    }else{
        $mensaje="No se pudo modificar ";
    }
        echo json_encode([
            'id'=>$id,
            'mensaje'=>$mensaje
        ]);
    }



}