import { ProductoService } from './../../servicios/producto.service';
import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.page.html',
  styleUrls: ['./productos.page.scss'],
})
export class ProductosPage implements OnInit {
  productos:any[]=[];
  mensaje:string="";

  constructor(
    private servP:ProductoService,
    private loading:LoadingController

    ) { }


  ngOnInit() {
  }
  ionViewWillEnter(){
   this.cargarProductos();
  }

  async cargarProductos(){
    let l=await this.loading.create();
    l.present();
   this.servP.get_listaProductos().subscribe(
     (respuesta:any)=>{
      this.productos=respuesta.data;
      //console.log(respuesta);
      //console.log(JSON.stringify(respuesta));
      this.mensaje=respuesta.mensaje;

      console.log(respuesta.cantidad);
      console.log(respuesta.mensaje);
      console.log(respuesta.data);
      l.dismiss();
     },(error:any)=>{
      this.mensaje="no se pudo conectar al servidor";
      l.dismiss();

     }

    )
    };
  }

