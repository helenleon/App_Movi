import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {
  public URLAPI:string="http://127.0.0.1:8080/api_ws_dbr/";
  constructor(private router:Router
 ) {}


irA(url:String){
 this.router.navigate([url]);

}
  
}
