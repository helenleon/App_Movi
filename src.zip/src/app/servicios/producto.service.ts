import { GeneralService } from './general.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductoService {
  

  constructor( 
    private servG:GeneralService,
    private http:HttpClient
    ) {  }

  get_listaProductos(){
    let URL=this.servG.URLAPI+'listadoProductos';
    //console.log(URL);
   return this.http.get<any[]>(URL);

  }
}
